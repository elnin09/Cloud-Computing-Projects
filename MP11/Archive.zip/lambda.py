import json
import boto3
import collections
import mysql.connector



    
def read():
    cnx = mysql.connector.connect(user='admin', password='darmora123',
                              host='darmoradb123.cluster-ro-cc1lsummhvn7.us-east-1.rds.amazonaws.com ',
                              database='mp11')
    cursor = cnx.cursor()
    
    query = ("SELECT * FROM mp11 "
         "WHERE f1 = %s")
    
    id = 23
    
    cursor.execute(query,(id))
    
    for (f1,f2,f3,f4,f5,f6) in cursor:
        print(f1,f2,f3,f4,f5,f6)
         
    try:
        with connection.cursor() as cursor:
            # Create a new record
            sql = "INSERT INTO `users` (`email`, `password`) VALUES (%s, %s)"
            #cursor.execute(sql, ('webmaster@python.org', 'very-secret'))
    
        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
    
        with connection.cursor() as cursor:
            # Read a single record
            sql = "SELECT & FROM `mp11` WHERE `f1`=%s"
            cursor.execute(sql, ('13',))
            result = cursor.fetchone()
            print(result)
    finally:
        connection.close()    

def lambda_handler(event, context):
    # TODO implement
    
    #input = event['queryStringParameters']['graph']
    #use-cache = event['USE_CACHE']
    #request = event['REQUEST']
    #sqls = event['SQLS']
    read()
    print(input)
    #print(input)
    DistanceGraph = calculatedistance(input)
    
   
    
    return {
        'statusCode': 200,
        'body': json.dumps(DistanceGraph)
    }
